import React from 'react'

const Filter = ({ value, onChange }) => {
    console.log('lol filter chal raha')
    return(
        <div>
                    find countriesssss

                <input value={value} onChange={onChange} />
    </div>
    )
}
export default Filter